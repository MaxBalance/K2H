//
//  WhatsAppConnection.h
//  WhatsAppConnection
//
//  Created by 刘 靖煌 on 14-5-19.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ShareSDK/ShareSDKPlugin.h>

///#begin zh-cn
/**
 *	@brief	WhatsApp连接器
 */
///#end
///#begin en
/**
 *	@brief	WhatsApp Connection
 */
///#end
@interface WhatsAppConnection : NSObject <ISSPlatform>

@end
